import {applyTheme as _applyTheme} from './theme-inventorymanagement.generated.js';
export const applyTheme = _applyTheme;
